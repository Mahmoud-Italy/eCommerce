<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryCtrl extends Controller
{
    public function index($value='')
    {
    	# code...
    }

    public function create($value='')
    {
    	# code...
    }
    public function store(Request $request)
    {
    	# code...
    }

    public function edit($id)
    {
    	# code...
    }

    public function update($id,Request $request)
    {
    	# code...
    }

    public function destroy($id)
    {
    	# code...
    }
}
