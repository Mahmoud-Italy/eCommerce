<?php

namespace App\Http\Controllers\backend;

use Session;
use Redirect;
use App\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryCtrl extends Controller
{
    public function index()
    {
    	$data = Category::get();
    	return view('backend.category.list')->withdata($data);
    }

    public function create()
    {
    	//select * FROM category where parent_id = 0
    	$data = Category::where('parent_id',0)->get();
    	return view('backend.category.create')->withdata($data);
    }

    public function store(Request $request)
    {
    	try {
    		$row = new Category;
    		$row->parent_id = $request->input('parent_id');
    		$row->name = $request->input('cat_name');
    		$row->active = $request->input('active');
    		$row->save();
    		Session::flash('success', 'Category Added Successfully');
    		return Redirect::to('dashboard/categories');
    	} catch (\Exception $e) {
    		Session::flash('error', 'Category Not Added');
    		return Redirect::back();
    	}
    }

    public function edit($id)
    {
    	# code...
    }

    public function update($value='')
    {
    	# code...
    }

    public function destroy($value='')
    {
    	# code...
    }
}
