<?php $__env->startSection('content'); ?>

<div class="wrapper">
              
          <!--Start Page Title-->
           <div class="page-title-box">
                <h4 class="page-title">Categories</h4>
                <div class="clearfix"></div>
             </div>
              <!--End Page Title-->          
           
           
               <!--Start row-->
               <div class="row">
                   <div class="col-md-12">
                       <div class="white-box">
                           <h2 class="header-title">Create New Category</h2>

                        <?php echo Form::Open(); ?>   
                            <div class="form-group">
                                <label>Parent</label>
                                <select class="form-control" name="parent_id">
                                  <option value="0">No Parent</option>
                                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($cat->id); ?>">[ <?php echo e($cat->name); ?> ]</option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" class="form-control" name="cat_name">
                            </div>
                            <div class="form-group">
                              <select class="form-control" name="active">
                                <option value="1">Actived</option>
                                <option value="0">DeActived</option>
                              </select>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-primary">Save</button>
                                <a href="<?php echo e(url('dashboard/categories')); ?>" class="btn btn-danger">Back</a>
                            </div>
                      <?php echo Form::Close(); ?>


                       </div>
                   </div>
               </div>
               <!--End row-->
       
               
               
               
			    </div>
        <!-- End Wrapper-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>