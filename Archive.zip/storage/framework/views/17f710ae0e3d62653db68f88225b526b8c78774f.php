<div class="only-banner ptb--100 bg__white">
            <div class="container">
                <div class="only-banner-img">
                    <a href="shop-sidebar.html"><img src="<?php echo e(url('frontend/images/new-product/3.jpg')); ?>" alt="new product"></a>
                </div>
            </div>
        </div>