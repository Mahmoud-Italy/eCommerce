<!DOCTYPE html>
<html>
<head>
	<title>Category</title>
</head>
<body>


<style>
tr td {border:1px solid #ddd;text-align: center;}
</style>
<br/>

<?php if(Session::has('success')): ?>
<p style="color:green"><?php echo e(Session::get('success')); ?></p>
<?php elseif(Session::has('error')): ?>
<p style="color:red"><?php echo e(Session::get('error')); ?></p>
<?php endif; ?>

<a href="<?php echo e(url('create')); ?>">Add New Category</a>
<br/><br/>
<?php echo Form::Open(['method'=>'GET']); ?>

<input type="text" name="search" placeholder="Search..." 
value="<?php if(isset($_GET['search'])): ?><?php echo e($_GET['search']); ?><?php endif; ?>">
<?php echo Form::Close(); ?>

<br/><br/>
<table style="border:1px solid #ddd;width: 500px;max-height:300px">
	<thead>
		<tr>
			<th>#</th>
			<th>Category Name</th>
			<th>Category Content</th>
			<th>Date</th>
			<th>Actions</th>
	   </tr>
	</thead>
	<tbody>


		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td><?php echo e($row->name); ?></td>
			<td><?php echo e($row->content); ?></td>
			<td><?php echo e(explode(' ',$row->created_at)[0]); ?></td>
			<td>
				<?php echo Form::Open(['url'=>'category/destroy/'.$row->id]); ?>

				<a href="<?php echo e(url('category/edit/'.$row->id)); ?>">edit</a>
				<button>Delete</button>
				<?php echo Form::Close(); ?>

			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>


</body>
</html>