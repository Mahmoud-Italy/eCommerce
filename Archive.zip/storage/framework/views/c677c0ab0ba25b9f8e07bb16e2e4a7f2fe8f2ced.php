<?php $__env->startSection('content'); ?>

<div class="wrapper">
              
          <!--Start Page Title-->
           <div class="page-title-box">
                <h4 class="page-title">Categories</h4>
                <div class="clearfix"></div>
             </div>
              <!--End Page Title-->          
           
               <?php if(Session::has('success')): ?>
               <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
               <?php elseif(Session::has('error')): ?>
               <p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
               <?php endif; ?>
               <!--Start row-->
               <div class="row">
                   <div class="col-md-12" style="text-align: right;">
                   	    <div class="form-group">
                           	<a href="<?php echo e(url('dashboard/categories/create')); ?>" class="btn btn-danger">Add New Category</a>
                        </div>
                       <div class="white-box" style="text-align: left">
                           <h2 class="header-title">All Data ( 0 )</h2>
                           
                            <div class="table-responsive">
                             <table id="example" class="display table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Parent</th>
                                            <th>Active</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td> <?php echo App\Category::getCategoryName($row->parent_id); ?> </td>
                                            <td><?php echo App\Category::getActive($row->active); ?></td>
                                            <td><?php echo e(explode(' ',$row->created_at)[0]); ?></td>
                                            <td>
                                            <?php echo Form::Open(['url'=>'dashboard/categories/destroy/'.$row->id]); ?>

                                                <a href="<?php echo e(url('dashboard/categories/edit/'.$row->id)); ?>" class="btn btn-success">Edit</a>
                                                <button class="btn btn-danger">Destroy</button>
                                            <?php echo Form::Close(); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                    </tbody>
                                   </table>  
                            </div>
                       </div>
                   </div>
               </div>
               <!--End row-->
       
               
               
               
			    </div>
        <!-- End Wrapper-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>