<div class="left-side sticky-left-side">

        <!--logo-->
        <div class="logo">
            <a href="index.html"><img src="<?php echo e(url('backend/assets/images/logo.png')); ?>" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.html"><img src="<?php echo e(url('backend/assets/images/logo-icon.png')); ?>" alt=""></a>
        </div>
        <!--logo-->

        <div class="left-side-inner">
            <!--Sidebar nav-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="menu-list nav-active">
                    <a href="#"><i class="icon-home"></i> <span>Dashboard</span></a>
                </li>

                <li class="menu-list"><a href="#"><i class="icon-layers"></i> <span>Categories</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo e(url('dashboard/categories')); ?>"> All Categories</a></li>
                        <li><a href="<?php echo e(url('dashboard/categories/create')); ?>"> Create New Category</a></li>
                    </ul>
                </li>
                
                <li class="menu-list"><a href="#"><i class="icon-grid"></i> <span>Products</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="#"> All Products</a></li>
                        <li><a href="#">Create New Product</a></li>
                    </ul>
                </li>



                <li class="menu-list"><a href="#"><i class="icon-grid"></i> <span>Orders</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="#"> All Orders</a></li>
                        <li><a href="#">Pending</a></li>
                        <li><a href="#">Completed</a></li>
                    </ul>
                </li>


                <li class="menu-list"><a href="#"><i class="icon-grid"></i> <span>Users</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="#"> All Users</a></li>
                        <li><a href="#">New Users</a></li>
                    </ul>
                </li>


                <li class="menu-list"><a href="#"><i class="icon-grid"></i> <span>Settings</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="#"> Update Info</a></li>
                    </ul>
                </li>

                

            </ul>
            <!--End sidebar nav-->

        </div>
    </div>